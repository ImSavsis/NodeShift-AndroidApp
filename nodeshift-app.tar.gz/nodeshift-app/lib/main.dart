import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'router/router.dart';
import 'services/vpn_service.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const NodeShiftApp());
}

class NodeShiftApp extends StatelessWidget {
  const NodeShiftApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => VpnService()),
      ],
      child: MaterialApp.router(
        title:            'NodeShift VPN',
        theme:            AppTheme.dark,
        routerConfig:     appRouter,
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}
