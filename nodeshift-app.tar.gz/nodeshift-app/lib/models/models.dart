class UserModel {
  final int    id;
  final String email;
  final bool   isVerified;
  final String? marzbanUsername;
  final String? displayName;
  final String? tgUsername;
  final String? tgFirstName;
  final String? tgAvatarUrl;

  const UserModel({
    required this.id,
    required this.email,
    required this.isVerified,
    this.marzbanUsername,
    this.displayName,
    this.tgUsername,
    this.tgFirstName,
    this.tgAvatarUrl,
  });

  factory UserModel.fromJson(Map<String, dynamic> j) => UserModel(
    id:               j['id']               as int,
    email:            j['email']            as String,
    isVerified:       (j['is_verified']      as bool?) ?? false,
    marzbanUsername:  j['marzban_username']  as String?,
    displayName:      j['display_name']      as String?,
    tgUsername:       j['tg_username']       as String?,
    tgFirstName:      j['tg_first_name']     as String?,
    tgAvatarUrl:      j['tg_avatar_url']     as String?,
  );

  bool get isTgUser  => email.contains('@tg.nodeshift');
  bool get hasVpn    => marzbanUsername != null;

  String get displayTitle =>
    displayName?.isNotEmpty == true
      ? displayName!
      : isTgUser
        ? (tgFirstName ?? tgUsername ?? 'Telegram')
        : email;

  String get initials =>
    displayTitle.isNotEmpty ? displayTitle[0].toUpperCase() : 'N';
}

class SubModel {
  final bool   hasSubscription;
  final String status;
  final String? expireAt;
  final int?   daysLeft;
  final String subscriptionUrl;
  final String? vlessLink;
  final double usedTrafficGb;
  final bool   frozen;
  final bool   trialUsed;

  const SubModel({
    required this.hasSubscription,
    required this.status,
    this.expireAt,
    this.daysLeft,
    required this.subscriptionUrl,
    this.vlessLink,
    required this.usedTrafficGb,
    required this.frozen,
    required this.trialUsed,
  });

  factory SubModel.fromJson(Map<String, dynamic> j) => SubModel(
    hasSubscription: (j['has_subscription'] as bool?) ?? false,
    status:          (j['status']           as String?) ?? 'inactive',
    expireAt:        j['expire_at']         as String?,
    daysLeft:        j['days_left']         as int?,
    subscriptionUrl: (j['subscription_url'] as String?) ?? '',
    vlessLink:       j['vless_link']        as String?,
    usedTrafficGb:   ((j['used_traffic_gb'] as num?) ?? 0).toDouble(),
    frozen:          (j['frozen']           as bool?) ?? false,
    trialUsed:       (j['trial_used']       as bool?) ?? false,
  );

  bool get isActive  => hasSubscription && status == 'active' && !isExpired;
  bool get isExpired => (daysLeft ?? 1) <= 0;

  String get daysText {
    final d = daysLeft ?? 0;
    if (d <= 0) return 'Истекла';
    if (d == 1) return '1 день';
    if (d < 5)  return '$d дня';
    return '$d дней';
  }
}
