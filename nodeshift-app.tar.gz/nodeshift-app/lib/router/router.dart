import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../screens/splash.dart';
import '../screens/onboarding.dart';
import '../screens/auth/auth_screen.dart';
import '../screens/auth/email_login.dart';
import '../screens/auth/email_register.dart';
import '../screens/home/home_screen.dart';
import '../screens/profile/profile_screen.dart';
import '../services/api.dart';

final appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      pageBuilder: (c, s) => _slide(s, const SplashScreen()),
    ),
    GoRoute(
      path: '/onboarding',
      pageBuilder: (c, s) => _slide(s, const OnboardingScreen()),
    ),
    GoRoute(
      path: '/auth',
      pageBuilder: (c, s) => _slide(s, const AuthScreen()),
      routes: [
        GoRoute(
          path: 'login',
          pageBuilder: (c, s) => _slide(s, const EmailLoginScreen()),
        ),
        GoRoute(
          path: 'register',
          pageBuilder: (c, s) => _slide(s, const EmailRegisterScreen()),
        ),
        GoRoute(
          path: 'callback',
          pageBuilder: (c, s) => _slide(s, _TgCallbackPage(
            code: s.uri.queryParameters['code'],
            error: s.uri.queryParameters['error'],
          )),
        ),
      ],
    ),
    GoRoute(
      path: '/home',
      pageBuilder: (c, s) => _fade(s, const HomeScreen()),
    ),
    GoRoute(
      path: '/profile',
      pageBuilder: (c, s) => _slide(s, const ProfileScreen()),
    ),
  ],
);

// ── Transitions ───────────────────────────────────────────────────────────────

CustomTransitionPage<void> _slide(GoRouterState s, Widget child) {
  return CustomTransitionPage<void>(
    key: s.pageKey,
    child: child,
    transitionDuration: const Duration(milliseconds: 350),
    transitionsBuilder: (_, animation, __, child) => SlideTransition(
      position: Tween(begin: const Offset(1.0, 0), end: Offset.zero)
          .animate(CurvedAnimation(parent: animation, curve: Curves.easeInOut)),
      child: child,
    ),
  );
}

CustomTransitionPage<void> _fade(GoRouterState s, Widget child) {
  return CustomTransitionPage<void>(
    key: s.pageKey,
    child: child,
    transitionDuration: const Duration(milliseconds: 400),
    transitionsBuilder: (_, animation, __, child) => FadeTransition(
      opacity: CurvedAnimation(parent: animation, curve: Curves.easeOut),
      child: child,
    ),
  );
}

// ── TG OAuth callback handler ─────────────────────────────────────────────────

class _TgCallbackPage extends StatefulWidget {
  final String? code;
  final String? error;
  const _TgCallbackPage({this.code, this.error});

  @override
  State<_TgCallbackPage> createState() => _TgCallbackPageState();
}

class _TgCallbackPageState extends State<_TgCallbackPage> {
  String _msg = 'Авторизация...';
  bool   _err = false;

  @override
  void initState() {
    super.initState();
    _handle();
  }

  Future<void> _handle() async {
    if (widget.error != null) {
      setState(() { _msg = 'Ошибка: ${widget.error}'; _err = true; });
      await Future.delayed(const Duration(seconds: 2));
      if (mounted) context.go('/auth');
      return;
    }
    if (widget.code == null) {
      setState(() { _msg = 'Код не найден'; _err = true; });
      await Future.delayed(const Duration(seconds: 2));
      if (mounted) context.go('/auth');
      return;
    }
    try {
      await Api().exchangeTgCode(widget.code!);
      if (mounted) context.go('/home');
    } catch (e) {
      setState(() { _msg = Api().apiError(e); _err = true; });
      await Future.delayed(const Duration(seconds: 2));
      if (mounted) context.go('/auth');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (!_err)
            const CircularProgressIndicator()
          else
            const Icon(Icons.error_outline, color: Colors.red, size: 48),
          const SizedBox(height: 16),
          Text(_msg),
        ],
      ),
    ),
  );
}
