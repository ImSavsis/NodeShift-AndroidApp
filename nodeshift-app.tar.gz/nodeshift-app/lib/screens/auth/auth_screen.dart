import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import '../../services/api.dart';
import '../../theme/app_theme.dart';
import 'email_login.dart';
import 'email_register.dart';

class AuthScreen extends StatelessWidget {
  const AuthScreen({super.key});

  Future<void> _openTgOAuth(BuildContext context) async {
    await Api().openTgOAuth();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.bg,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            children: [
              const Spacer(flex: 2),
              // Logo
              Column(
                children: [
                  Container(
                    width: 72, height: 72,
                    decoration: BoxDecoration(
                      color: C.accent.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: C.accent.withOpacity(0.25)),
                    ),
                    child: const Icon(Icons.shield_rounded, color: C.accent, size: 36),
                  )
                      .animate().scale(duration: 500.ms, curve: Curves.elasticOut),
                  const SizedBox(height: 20),
                  const Text('NodeShift VPN',
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, color: C.t1, letterSpacing: -0.5),
                  ).animate().fadeIn(delay: 200.ms),
                  const SizedBox(height: 8),
                  const Text('Быстро. Надёжно. Конфиденциально.',
                    style: TextStyle(fontSize: 14, color: C.t3),
                  ).animate().fadeIn(delay: 300.ms),
                ],
              ),
              const Spacer(flex: 2),

              // Telegram button (primary)
              _TgButton(onTap: () => _openTgOAuth(context))
                  .animate().slideY(begin: 0.3, duration: 400.ms, delay: 300.ms, curve: Curves.easeOut)
                  .fadeIn(delay: 300.ms),

              const SizedBox(height: 12),

              // Divider
              Row(
                children: [
                  const Expanded(child: Divider(color: C.border)),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Text('или', style: TextStyle(color: C.t3, fontSize: 13)),
                  ),
                  const Expanded(child: Divider(color: C.border)),
                ],
              ).animate().fadeIn(delay: 400.ms),

              const SizedBox(height: 12),

              // Email login
              SizedBox(
                width: double.infinity, height: 52,
                child: OutlinedButton(
                  onPressed: () => context.push('/auth/login'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: C.t1,
                    side: const BorderSide(color: C.border),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: const Text('Войти по email', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500)),
                ),
              ).animate().fadeIn(delay: 450.ms),

              const SizedBox(height: 10),

              // Register
              SizedBox(
                width: double.infinity, height: 52,
                child: TextButton(
                  onPressed: () => context.push('/auth/register'),
                  style: TextButton.styleFrom(
                    foregroundColor: C.t2,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: const Text('Создать аккаунт', style: TextStyle(fontSize: 15)),
                ),
              ).animate().fadeIn(delay: 500.ms),

              const Spacer(),
            ],
          ),
        ),
      ),
    );
  }
}

class _TgButton extends StatelessWidget {
  final VoidCallback onTap;
  const _TgButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity, height: 56,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF2AABEE),
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          elevation: 0,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/telegram.png', width: 24, height: 24,
              errorBuilder: (_, __, ___) => const Icon(Icons.telegram, size: 24),
            ),
            const SizedBox(width: 10),
            const Text('Войти через Telegram',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }
}
