import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../services/api.dart';
import '../../theme/app_theme.dart';
import '../../widgets/ns_button.dart';
import '../../widgets/ns_field.dart';

class EmailLoginScreen extends StatefulWidget {
  const EmailLoginScreen({super.key});

  @override
  State<EmailLoginScreen> createState() => _EmailLoginScreenState();
}

class _EmailLoginScreenState extends State<EmailLoginScreen> {
  final _emailCtrl = TextEditingController();
  final _codeCtrl  = TextEditingController();
  bool   _step2    = false;
  bool   _loading  = false;
  String _error    = '';

  @override
  void dispose() {
    _emailCtrl.dispose();
    _codeCtrl.dispose();
    super.dispose();
  }

  Future<void> _sendCode() async {
    final email = _emailCtrl.text.trim();
    if (email.isEmpty) { setState(() => _error = 'Введите email'); return; }
    setState(() { _loading = true; _error = ''; });
    try {
      await Api().sendLoginCode(email);
      setState(() { _step2 = true; });
    } catch (e) {
      setState(() => _error = Api().apiError(e));
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _verify() async {
    final email = _emailCtrl.text.trim();
    final code  = _codeCtrl.text.trim();
    if (code.isEmpty) { setState(() => _error = 'Введите код'); return; }
    setState(() { _loading = true; _error = ''; });
    try {
      await Api().verifyLoginCode(email, code);
      if (mounted) context.go('/home');
    } catch (e) {
      setState(() => _error = Api().apiError(e));
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Вход по email')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_step2 ? 'Введите код из письма' : 'Введите email',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: C.t1)),
            const SizedBox(height: 8),
            Text(_step2
              ? 'Мы отправили 6-значный код на ${_emailCtrl.text}'
              : 'Мы пришлём код для входа',
              style: const TextStyle(color: C.t2, fontSize: 14)),
            const SizedBox(height: 28),
            if (!_step2) ...[
              NsField(
                controller: _emailCtrl,
                hint: 'email@example.com',
                keyboardType: TextInputType.emailAddress,
                autofocus: true,
              ),
            ] else ...[
              NsField(
                controller: _codeCtrl,
                hint: '123456',
                keyboardType: TextInputType.number,
                autofocus: true,
                maxLength: 6,
              ),
            ],
            if (_error.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text(_error, style: const TextStyle(color: C.red, fontSize: 13)),
            ],
            const SizedBox(height: 20),
            NsButton(
              label: _step2 ? 'Войти' : 'Получить код',
              loading: _loading,
              onTap: _step2 ? _verify : _sendCode,
            ),
            if (_step2) ...[
              const SizedBox(height: 16),
              Center(
                child: TextButton(
                  onPressed: () => setState(() { _step2 = false; _codeCtrl.clear(); _error = ''; }),
                  child: const Text('Изменить email', style: TextStyle(color: C.t2)),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
