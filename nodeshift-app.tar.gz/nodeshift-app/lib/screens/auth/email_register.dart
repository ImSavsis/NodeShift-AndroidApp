import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../services/api.dart';
import '../../theme/app_theme.dart';
import '../../widgets/ns_button.dart';
import '../../widgets/ns_field.dart';

class EmailRegisterScreen extends StatefulWidget {
  const EmailRegisterScreen({super.key});

  @override
  State<EmailRegisterScreen> createState() => _EmailRegisterScreenState();
}

class _EmailRegisterScreenState extends State<EmailRegisterScreen> {
  final _emailCtrl = TextEditingController();
  final _passCtrl  = TextEditingController();
  final _codeCtrl  = TextEditingController();
  bool   _step2    = false;
  bool   _loading  = false;
  bool   _obscure  = true;
  String _error    = '';

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    _codeCtrl.dispose();
    super.dispose();
  }

  Future<void> _register() async {
    final email = _emailCtrl.text.trim();
    final pass  = _passCtrl.text;
    if (email.isEmpty || pass.isEmpty) {
      setState(() => _error = 'Заполните все поля');
      return;
    }
    if (pass.length < 8) {
      setState(() => _error = 'Пароль минимум 8 символов');
      return;
    }
    setState(() { _loading = true; _error = ''; });
    try {
      await Api().sendRegCode(email, pass);
      setState(() { _step2 = true; });
    } catch (e) {
      setState(() => _error = Api().apiError(e));
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _verify() async {
    final email = _emailCtrl.text.trim();
    final code  = _codeCtrl.text.trim();
    if (code.isEmpty) { setState(() => _error = 'Введите код'); return; }
    setState(() { _loading = true; _error = ''; });
    try {
      await Api().verifyRegCode(email, code);
      if (mounted) context.go('/home');
    } catch (e) {
      setState(() => _error = Api().apiError(e));
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Регистрация')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(_step2 ? 'Подтвердите email' : 'Создать аккаунт',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: C.t1)),
            const SizedBox(height: 8),
            Text(_step2
              ? 'Код отправлен на ${_emailCtrl.text}'
              : 'Введите данные для регистрации',
              style: const TextStyle(color: C.t2, fontSize: 14)),
            const SizedBox(height: 28),
            if (!_step2) ...[
              NsField(
                controller: _emailCtrl,
                hint: 'email@example.com',
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 12),
              NsField(
                controller: _passCtrl,
                hint: 'Пароль (мин. 8 символов)',
                obscureText: _obscure,
                suffix: IconButton(
                  icon: Icon(_obscure ? Icons.visibility_off : Icons.visibility, color: C.t3),
                  onPressed: () => setState(() => _obscure = !_obscure),
                ),
              ),
            ] else ...[
              NsField(
                controller: _codeCtrl,
                hint: '123456',
                keyboardType: TextInputType.number,
                autofocus: true,
                maxLength: 6,
              ),
            ],
            if (_error.isNotEmpty) ...[
              const SizedBox(height: 12),
              Text(_error, style: const TextStyle(color: C.red, fontSize: 13)),
            ],
            const SizedBox(height: 20),
            NsButton(
              label: _step2 ? 'Подтвердить' : 'Зарегистрироваться',
              loading: _loading,
              onTap: _step2 ? _verify : _register,
            ),
          ],
        ),
      ),
    );
  }
}
