import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../models/models.dart';
import '../../services/api.dart';
import '../../services/vpn_service.dart';
import '../../theme/app_theme.dart';
import '../../widgets/ns_button.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  SubModel? _sub;
  bool      _loadingSub = false;
  String    _subError   = '';

  @override
  void initState() {
    super.initState();
    _loadSub();
  }

  Future<void> _loadSub() async {
    setState(() { _loadingSub = true; _subError = ''; });
    try {
      final sub = await Api().getSub();
      setState(() => _sub = sub);
    } catch (e) {
      setState(() => _subError = Api().apiError(e));
    } finally {
      setState(() => _loadingSub = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final vpn  = context.watch<VpnService>();
    final user = Api().me;

    return Scaffold(
      backgroundColor: C.bg,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _loadSub,
          color: C.accent,
          backgroundColor: C.card,
          child: CustomScrollView(
            slivers: [
              _AppBar(user: user),
              SliverPadding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([
                    const SizedBox(height: 8),
                    _VpnToggle(vpn: vpn, sub: _sub),
                    const SizedBox(height: 20),
                    if (_loadingSub)
                      const Center(child: CircularProgressIndicator(color: C.accent))
                    else if (_subError.isNotEmpty)
                      _ErrorCard(message: _subError, onRetry: _loadSub)
                    else if (_sub != null)
                      _SubCard(sub: _sub!),
                    const SizedBox(height: 20),
                    if (_sub != null && !_sub!.hasSubscription) _TrialCard(),
                    const SizedBox(height: 40),
                  ]),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── App Bar ───────────────────────────────────────────────────────────────────

class _AppBar extends StatelessWidget {
  final UserModel? user;
  const _AppBar({this.user});

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      backgroundColor: C.bg,
      floating: true,
      automaticallyImplyLeading: false,
      title: Row(
        children: [
          Container(
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: C.accent.withOpacity(0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.shield_rounded, color: C.accent, size: 20),
          ),
          const SizedBox(width: 10),
          const Text('NodeShift', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
        ],
      ),
      actions: [
        GestureDetector(
          onTap: () => context.push('/profile'),
          child: Container(
            margin: const EdgeInsets.only(right: 16),
            width: 36, height: 36,
            decoration: BoxDecoration(
              color: C.card,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: C.border),
            ),
            child: user?.tgAvatarUrl != null
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(9),
                  child: Image.network(user!.tgAvatarUrl!, fit: BoxFit.cover),
                )
              : Center(
                  child: Text(user?.initials ?? 'N',
                    style: const TextStyle(color: C.t1, fontWeight: FontWeight.w600, fontSize: 15)),
                ),
          ),
        ),
      ],
    );
  }
}

// ── VPN Toggle ────────────────────────────────────────────────────────────────

class _VpnToggle extends StatelessWidget {
  final VpnService vpn;
  final SubModel?  sub;
  const _VpnToggle({required this.vpn, this.sub});

  Color get _color {
    switch (vpn.status) {
      case VpnStatus.connected:    return C.green;
      case VpnStatus.connecting:
      case VpnStatus.disconnecting: return C.yellow;
      case VpnStatus.error:        return C.red;
      default:                      return C.t3;
    }
  }

  String get _label {
    switch (vpn.status) {
      case VpnStatus.connected:     return 'Подключено';
      case VpnStatus.connecting:    return 'Подключение...';
      case VpnStatus.disconnecting: return 'Отключение...';
      case VpnStatus.error:         return 'Ошибка';
      default:                       return 'Отключено';
    }
  }

  @override
  Widget build(BuildContext context) {
    final canToggle = sub?.vlessLink != null;
    return Column(
      children: [
        const SizedBox(height: 32),
        // Big glowing button
        GestureDetector(
          onTap: canToggle ? () => vpn.toggle(sub?.vlessLink) : null,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 400),
            curve: Curves.easeInOut,
            width: 160, height: 160,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: C.card,
              border: Border.all(color: _color.withOpacity(0.5), width: 2),
              boxShadow: [
                BoxShadow(
                  color: _color.withOpacity(vpn.connected ? 0.3 : 0.1),
                  blurRadius: vpn.connected ? 40 : 20,
                  spreadRadius: vpn.connected ? 8 : 0,
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  vpn.connected ? Icons.power_settings_new : Icons.power_settings_new_outlined,
                  color: _color,
                  size: 56,
                ),
              ],
            ),
          ),
        )
            .animate(target: vpn.connected ? 1 : 0)
            .scaleXY(begin: 1.0, end: 1.05, curve: Curves.easeInOut),
        const SizedBox(height: 16),
        Text(_label,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: _color,
          ),
        ),
        if (vpn.error.isNotEmpty) ...[
          const SizedBox(height: 4),
          Text(vpn.error, style: const TextStyle(color: C.red, fontSize: 12)),
        ],
        const SizedBox(height: 32),
      ],
    );
  }
}

// ── Subscription Card ─────────────────────────────────────────────────────────

class _SubCard extends StatelessWidget {
  final SubModel sub;
  const _SubCard({required this.sub});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: C.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: sub.isActive ? C.green.withOpacity(0.3) : C.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: sub.isActive ? C.green.withOpacity(0.15) : C.t3.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  sub.isActive ? 'Активна' : sub.status,
                  style: TextStyle(
                    color: sub.isActive ? C.green : C.t3,
                    fontSize: 12, fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              const Spacer(),
              if (sub.daysLeft != null)
                Text(sub.daysText, style: const TextStyle(color: C.t2, fontSize: 13)),
            ],
          ),
          const SizedBox(height: 16),
          Row(children: [
            _StatItem(label: 'Трафик', value: '${sub.usedTrafficGb.toStringAsFixed(1)} ГБ'),
            const SizedBox(width: 24),
            if (sub.expireAt != null)
              _StatItem(label: 'Истекает', value: _formatDate(sub.expireAt!)),
          ]),
          if (sub.isActive && sub.subscriptionUrl.isNotEmpty) ...[
            const SizedBox(height: 16),
            const Divider(color: C.border),
            const SizedBox(height: 12),
            _CopyRow(label: 'Ссылка подписки', value: sub.subscriptionUrl),
          ],
        ],
      ),
    ).animate().fadeIn(duration: 400.ms).slideY(begin: 0.1);
  }

  String _formatDate(String iso) {
    try {
      final d = DateTime.parse(iso);
      return '${d.day.toString().padLeft(2,'0')}.${d.month.toString().padLeft(2,'0')}.${d.year}';
    } catch (_) { return iso; }
  }
}

class _StatItem extends StatelessWidget {
  final String label, value;
  const _StatItem({required this.label, required this.value});

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(label, style: const TextStyle(color: C.t3, fontSize: 11)),
      const SizedBox(height: 2),
      Text(value,  style: const TextStyle(color: C.t1, fontSize: 15, fontWeight: FontWeight.w600)),
    ],
  );
}

class _CopyRow extends StatelessWidget {
  final String label, value;
  const _CopyRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) => Row(
    children: [
      Expanded(child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: C.t3, fontSize: 11)),
          const SizedBox(height: 2),
          Text(value,
            style: const TextStyle(color: C.t2, fontSize: 11),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      )),
      IconButton(
        icon: const Icon(Icons.copy, size: 16, color: C.t3),
        onPressed: () {
          // copy to clipboard
        },
      ),
    ],
  );
}

// ── Trial card ────────────────────────────────────────────────────────────────

class _TrialCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [C.accent.withOpacity(0.12), C.accent.withOpacity(0.04)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: C.accent.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Попробуйте бесплатно',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: C.t1)),
          const SizedBox(height: 6),
          const Text('3 дня VPN без ограничений. Карта не нужна.',
            style: TextStyle(color: C.t2, fontSize: 13)),
          const SizedBox(height: 16),
          NsButton(
            label: 'Активировать пробный период',
            onTap: () async {
              try {
                await Api().activateTrial();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Пробный период активирован!')),
                );
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(Api().apiError(e))),
                );
              }
            },
          ),
        ],
      ),
    ).animate().fadeIn(delay: 200.ms).slideY(begin: 0.15);
  }
}

// ── Error card ────────────────────────────────────────────────────────────────

class _ErrorCard extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorCard({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: C.red.withOpacity(0.1),
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: C.red.withOpacity(0.3)),
    ),
    child: Row(children: [
      const Icon(Icons.error_outline, color: C.red, size: 20),
      const SizedBox(width: 12),
      Expanded(child: Text(message, style: const TextStyle(color: C.red, fontSize: 13))),
      TextButton(onPressed: onRetry, child: const Text('Повтор', style: TextStyle(color: C.red))),
    ]),
  );
}
