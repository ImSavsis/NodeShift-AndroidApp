import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import '../theme/app_theme.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final _controller = PageController();
  int _page = 0;

  static const _pages = [
    _OnboardPage(
      icon:    Icons.lock_rounded,
      title:   'Полная защита',
      body:    'Шифрование трафика на всех устройствах. Никто не увидит, что и куда вы передаёте.',
    ),
    _OnboardPage(
      icon:    Icons.speed_rounded,
      title:   'Быстрое соединение',
      body:    'Серверы в 20+ странах. Протокол VLESS — минимальная задержка, максимальная скорость.',
    ),
    _OnboardPage(
      icon:    Icons.devices_rounded,
      title:   'Любые устройства',
      body:    'Одна подписка — до 4 одновременных подключений. Android, iOS, Windows, Mac.',
    ),
  ];

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _next() {
    if (_page < _pages.length - 1) {
      _controller.nextPage(
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeInOut,
      );
    } else {
      context.go('/auth');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.bg,
      body: SafeArea(
        child: Column(
          children: [
            Align(
              alignment: Alignment.topRight,
              child: TextButton(
                onPressed: () => context.go('/auth'),
                child: Text('Пропустить', style: TextStyle(color: C.t2, fontSize: 14)),
              ),
            ),
            Expanded(
              child: PageView.builder(
                controller: _controller,
                itemCount:  _pages.length,
                onPageChanged: (i) => setState(() => _page = i),
                itemBuilder: (_, i) => _pages[i],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 32),
              child: Column(
                children: [
                  SmoothPageIndicator(
                    controller: _controller,
                    count:      _pages.length,
                    effect: const WormEffect(
                      dotColor:       C.border,
                      activeDotColor: C.accent,
                      dotHeight: 8,
                      dotWidth:  8,
                    ),
                  ),
                  const SizedBox(height: 32),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton(
                      onPressed: _next,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: C.accent,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        elevation: 0,
                      ),
                      child: Text(
                        _page == _pages.length - 1 ? 'Начать' : 'Далее',
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OnboardPage extends StatelessWidget {
  final IconData icon;
  final String   title;
  final String   body;

  const _OnboardPage({required this.icon, required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 96, height: 96,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [C.accent.withOpacity(0.2), C.accent.withOpacity(0.05)],
                begin: Alignment.topLeft, end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: C.accent.withOpacity(0.25), width: 1.5),
            ),
            child: Icon(icon, color: C.accent, size: 44),
          ),
          const SizedBox(height: 40),
          Text(title,
            style: const TextStyle(
              fontSize: 26, fontWeight: FontWeight.w700,
              color: C.t1, letterSpacing: -0.5,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          Text(body,
            style: const TextStyle(fontSize: 15, color: C.t2, height: 1.6),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
