import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../models/models.dart';
import '../../services/api.dart';
import '../../theme/app_theme.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = Api().me;

    return Scaffold(
      appBar: AppBar(title: const Text('Профиль')),
      body: user == null
        ? const Center(child: CircularProgressIndicator(color: C.accent))
        : ListView(
            padding: const EdgeInsets.all(20),
            children: [
              _Avatar(user: user),
              const SizedBox(height: 24),
              _InfoCard(user: user),
              const SizedBox(height: 16),
              _ActionTile(
                icon:  Icons.logout,
                label: 'Выйти',
                color: C.red,
                onTap: () async {
                  await Api().logout();
                  if (context.mounted) context.go('/auth');
                },
              ),
              const SizedBox(height: 24),
              Center(
                child: Text('NodeShift VPN · v1.0.0',
                  style: TextStyle(color: C.t3, fontSize: 12)),
              ),
            ],
          ),
    );
  }
}

class _Avatar extends StatelessWidget {
  final UserModel user;
  const _Avatar({required this.user});

  @override
  Widget build(BuildContext context) => Column(
    children: [
      Container(
        width: 80, height: 80,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: C.card,
          border: Border.all(color: C.border, width: 2),
        ),
        child: user.tgAvatarUrl != null
          ? ClipOval(child: Image.network(user.tgAvatarUrl!, fit: BoxFit.cover))
          : Center(
              child: Text(user.initials,
                style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w700, color: C.t1)),
            ),
      ),
      const SizedBox(height: 12),
      Text(user.displayTitle,
        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: C.t1)),
      const SizedBox(height: 4),
      Text(user.email, style: const TextStyle(color: C.t3, fontSize: 13)),
    ],
  );
}

class _InfoCard extends StatelessWidget {
  final UserModel user;
  const _InfoCard({required this.user});

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: C.card,
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: C.border),
    ),
    child: Column(
      children: [
        if (user.tgUsername != null)
          _Row(icon: Icons.telegram, label: 'Telegram', value: '@${user.tgUsername}'),
        _Row(icon: Icons.email_outlined, label: 'Email', value: user.email),
        _Row(
          icon:  Icons.verified_outlined,
          label: 'Аккаунт',
          value: user.isVerified ? 'Подтверждён' : 'Не подтверждён',
          valueColor: user.isVerified ? C.green : C.yellow,
        ),
        if (user.marzbanUsername != null)
          _Row(icon: Icons.vpn_key_outlined, label: 'VPN профиль', value: user.marzbanUsername!),
      ],
    ),
  );
}

class _Row extends StatelessWidget {
  final IconData icon;
  final String   label;
  final String   value;
  final Color?   valueColor;
  const _Row({required this.icon, required this.label, required this.value, this.valueColor});

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
    child: Row(children: [
      Icon(icon, color: C.t3, size: 18),
      const SizedBox(width: 12),
      Text(label, style: const TextStyle(color: C.t2, fontSize: 14)),
      const Spacer(),
      Text(value, style: TextStyle(color: valueColor ?? C.t1, fontSize: 14, fontWeight: FontWeight.w500)),
    ]),
  );
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String   label;
  final Color    color;
  final VoidCallback onTap;
  const _ActionTile({required this.icon, required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(width: 12),
        Text(label, style: TextStyle(color: color, fontSize: 15, fontWeight: FontWeight.w600)),
      ]),
    ),
  );
}
