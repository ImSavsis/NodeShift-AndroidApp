import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../services/api.dart';
import '../theme/app_theme.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double>    _fade;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _fade = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);
    _ctrl.forward();
    _checkAuth();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _checkAuth() async {
    await Future.delayed(const Duration(milliseconds: 1200));
    if (!mounted) return;
    final loggedIn = await Api().isLoggedIn;
    if (!mounted) return;
    if (loggedIn) {
      try {
        await Api().getMe();
        if (mounted) context.go('/home');
      } catch (_) {
        if (mounted) context.go('/auth');
      }
    } else {
      context.go('/onboarding');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.bg,
      body: Center(
        child: FadeTransition(
          opacity: _fade,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 80, height: 80,
                decoration: BoxDecoration(
                  color: C.accent.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: C.accent.withOpacity(0.3)),
                ),
                child: const Icon(Icons.shield_rounded, color: C.accent, size: 40),
              ),
              const SizedBox(height: 20),
              Text('NodeShift',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.w700, color: C.t1, letterSpacing: -0.5,
                )),
              const SizedBox(height: 6),
              Text('VPN', style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: C.t3)),
              const SizedBox(height: 48),
              SizedBox(
                width: 24, height: 24,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: C.accent.withOpacity(0.6),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
