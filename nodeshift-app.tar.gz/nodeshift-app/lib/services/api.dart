import 'package:dio/dio.dart';
import 'package:dio_cookie_manager/dio_cookie_manager.dart';
import 'package:cookie_jar/cookie_jar.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../models/models.dart';

const kBase = 'https://nodeshift.space';
// Telegram Bot numeric ID (from token 8035304453:...)
const kBotId = '8035304453';

class Api {
  static final Api _i = Api._();
  factory Api() => _i;

  late final Dio _dio;
  late final CookieJar _jar;
  final _s = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  UserModel? _me;
  UserModel? get me => _me;

  Api._() {
    _jar = CookieJar();
    _dio = Dio(BaseOptions(
      baseUrl: kBase,
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 30),
      headers: {
        'Accept':       'application/json',
        'Content-Type': 'application/json',
        'Origin':       kBase,
      },
    ))
      ..interceptors.add(CookieManager(_jar))
      ..interceptors.add(InterceptorsWrapper(
        onError: (e, h) async {
          if (e.response?.statusCode == 401) {
            final ok = await _refresh();
            if (ok) return h.resolve(await _dio.fetch(e.requestOptions));
          }
          h.next(e);
        },
      ));
  }

  Future<bool> _refresh() async {
    try { await _dio.post('/api/auth/refresh'); return true; } catch (_) { return false; }
  }

  // ── Helpers ──────────────────────────────────────────────────────────────

  String apiError(dynamic e) {
    if (e is DioException) {
      final d = e.response?.data;
      if (d is Map) return d['detail']?.toString() ?? 'Ошибка сервера';
      return 'Ошибка ${e.response?.statusCode ?? "сети"}';
    }
    return e.toString();
  }

  Future<void> _saveLoggedIn() => _s.write(key: 'logged_in', value: '1');
  Future<void> clearAuth()      => Future.wait([
    _s.delete(key: 'logged_in'),
    _jar.deleteAll(),
  ]);

  Future<bool> get isLoggedIn async =>
      (await _s.read(key: 'logged_in')) == '1';

  // ── Telegram OAuth ────────────────────────────────────────────────────────

  static const _browserChannel = MethodChannel('space.nodeshift.vpn/browser');

  /// Opens Telegram OAuth in Chrome Custom Tab.
  Future<void> openTgOAuth() async {
    final url = tgOAuthUrl();
    try {
      await _browserChannel.invokeMethod('launchCustomTab', {'url': url});
    } catch (_) {
      // ignore: platform channel not available in test
    }
  }

  /// Builds the OAuth URL.
  String tgOAuthUrl() {
    const origin   = Uri.encodeComponent(kBase);
    const returnTo = Uri.encodeComponent('$kBase/tg-mobile-cb');
    return 'https://oauth.telegram.org/auth'
        '?bot_id=$kBotId'
        '&origin=$origin'
        '&return_to=$returnTo'
        '&request_access=write';
  }

  /// Exchange short-lived code for session (called after deep link callback).
  Future<UserModel> exchangeTgCode(String code) async {
    final r = await _dio.get('/api/auth/tg-mobile/exchange', queryParameters: {'code': code});
    final user = UserModel.fromJson(r.data as Map<String, dynamic>);
    _me = user;
    await _saveLoggedIn();
    return user;
  }

  // ── Email auth ────────────────────────────────────────────────────────────

  Future<void> sendLoginCode(String email) async =>
      _dio.post('/api/auth/login', data: {'email': email});

  Future<void> sendRegCode(String email, String password) async =>
      _dio.post('/api/auth/register', data: {'email': email, 'password': password});

  Future<UserModel> verifyLoginCode(String email, String code) async {
    final r = await _dio.post('/api/auth/verify-login', data: {'email': email, 'code': code});
    final user = UserModel.fromJson(r.data as Map<String, dynamic>);
    _me = user; await _saveLoggedIn(); return user;
  }

  Future<UserModel> verifyRegCode(String email, String code) async {
    final r = await _dio.post('/api/auth/verify', data: {'email': email, 'code': code});
    final user = UserModel.fromJson(r.data as Map<String, dynamic>);
    _me = user; await _saveLoggedIn(); return user;
  }

  // ── User ──────────────────────────────────────────────────────────────────

  Future<UserModel> getMe() async {
    final r = await _dio.get('/api/auth/me');
    _me = UserModel.fromJson(r.data as Map<String, dynamic>);
    return _me!;
  }

  Future<SubModel> getSub() async {
    final r = await _dio.get('/api/user/subscription');
    return SubModel.fromJson(r.data as Map<String, dynamic>);
  }

  Future<void> logout() async {
    try { await _dio.post('/api/auth/logout'); } catch (_) {}
    _me = null;
    await clearAuth();
  }

  Future<void> activateTrial() =>
      _dio.post('/api/payment/create', data: {'plan_key': '3d'});
}
