import 'package:flutter/foundation.dart';
import 'package:flutter_v2ray/flutter_v2ray.dart';

enum VpnStatus { disconnected, connecting, connected, disconnecting, error }

class VpnService extends ChangeNotifier {
  static final VpnService _i = VpnService._();
  factory VpnService() => _i;

  VpnStatus _status = VpnStatus.disconnected;
  String?   _vlessLink;
  String    _error = '';

  VpnStatus get status    => _status;
  bool      get connected => _status == VpnStatus.connected;
  String    get error     => _error;

  late final FlutterV2ray _v2ray;

  VpnService._() {
    _v2ray = FlutterV2ray(
      onStatusChanged: (status) {
        switch (status.state) {
          case 'CONNECTED':
            _status = VpnStatus.connected;
          case 'CONNECTING':
            _status = VpnStatus.connecting;
          case 'DISCONNECTED':
            _status = VpnStatus.disconnected;
          case 'DISCONNECTING':
            _status = VpnStatus.disconnecting;
          default:
            _status = VpnStatus.disconnected;
        }
        notifyListeners();
      },
    );
    _v2ray.initializeV2Ray();
  }

  Future<void> connect(String vlessLink) async {
    try {
      _vlessLink = vlessLink;
      _error = '';
      _status = VpnStatus.connecting;
      notifyListeners();

      final permission = await FlutterV2ray.requestPermission();
      if (!permission) {
        _error = 'VPN permission denied';
        _status = VpnStatus.error;
        notifyListeners();
        return;
      }

      final config = FlutterV2ray.parseFromURL(vlessLink);
      await _v2ray.startV2Ray(
        remark:    config.remark,
        config:    config.getFullConfiguration(),
        blockedApps: const [],
        proxyOnly: false,
      );
    } catch (e) {
      _error  = e.toString();
      _status = VpnStatus.error;
      notifyListeners();
    }
  }

  Future<void> disconnect() async {
    _status = VpnStatus.disconnecting;
    notifyListeners();
    await _v2ray.stopV2Ray();
  }

  Future<void> toggle(String? vlessLink) async {
    if (connected) {
      await disconnect();
    } else if (vlessLink != null) {
      await connect(vlessLink);
    }
  }
}
