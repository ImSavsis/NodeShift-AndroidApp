import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class C {
  static const bg      = Color(0xFF0a0a0a);
  static const surf    = Color(0xFF111111);
  static const card    = Color(0xFF161616);
  static const card2   = Color(0xFF1c1c1c);
  static const border  = Color(0xFF252525);
  static const accent  = Color(0xFF3B82F6);
  static const green   = Color(0xFF4ADE80);
  static const red     = Color(0xFFEF4444);
  static const yellow  = Color(0xFFFBBF24);
  static const t1      = Color(0xFFFFFFFF);
  static const t2      = Color(0xFFAAAAAA);
  static const t3      = Color(0xFF555555);
}

class AppTheme {
  static ThemeData get dark {
    final base = ThemeData.dark(useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: C.bg,
      colorScheme: const ColorScheme.dark(
        surface: C.surf,
        primary: C.accent,
        error:   C.red,
      ),
      textTheme: GoogleFonts.interTextTheme(base.textTheme).apply(
        bodyColor:    C.t1,
        displayColor: C.t1,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: C.bg,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        iconTheme: const IconThemeData(color: C.t1, size: 22),
        titleTextStyle: GoogleFonts.inter(
          fontSize: 16, fontWeight: FontWeight.w600, color: C.t1,
        ),
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor:             Colors.transparent,
          statusBarIconBrightness:    Brightness.light,
          systemNavigationBarColor:   C.bg,
          systemNavigationBarIconBrightness: Brightness.light,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: C.card,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: C.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: C.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: C.accent, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: C.red),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: C.red, width: 1.5),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        hintStyle: const TextStyle(color: C.t3, fontSize: 15),
        labelStyle: const TextStyle(color: C.t2, fontSize: 14),
        errorStyle: const TextStyle(color: C.red, fontSize: 12),
      ),
      cardTheme: CardTheme(
        color: C.card,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: const BorderSide(color: C.border),
        ),
      ),
      dividerTheme: const DividerThemeData(color: C.border, thickness: 1),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: C.card,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
      ),
      dialogTheme: DialogTheme(
        backgroundColor: C.card,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: C.card2,
        contentTextStyle: GoogleFonts.inter(color: C.t1, fontSize: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        behavior: SnackBarBehavior.floating,
      ),
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: PredictiveBackPageTransitionsBuilder(),
        },
      ),
    );
  }
}
