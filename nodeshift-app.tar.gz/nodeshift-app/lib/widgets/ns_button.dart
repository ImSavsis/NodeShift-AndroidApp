import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class NsButton extends StatelessWidget {
  final String   label;
  final VoidCallback? onTap;
  final bool     loading;
  final Color?   color;
  final IconData? icon;

  const NsButton({
    super.key,
    required this.label,
    this.onTap,
    this.loading = false,
    this.color,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton(
        onPressed: loading ? null : onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: color ?? C.accent,
          foregroundColor: Colors.white,
          disabledBackgroundColor: (color ?? C.accent).withOpacity(0.5),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          elevation: 0,
        ),
        child: loading
          ? const SizedBox(
              width: 20, height: 20,
              child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
            )
          : Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (icon != null) ...[Icon(icon, size: 20), const SizedBox(width: 8)],
                Text(label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              ],
            ),
      ),
    );
  }
}
