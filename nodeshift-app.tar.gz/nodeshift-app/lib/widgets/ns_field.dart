import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class NsField extends StatelessWidget {
  final TextEditingController controller;
  final String          hint;
  final TextInputType?  keyboardType;
  final bool            obscureText;
  final bool            autofocus;
  final int?            maxLength;
  final Widget?         suffix;
  final String?         label;

  const NsField({
    super.key,
    required this.controller,
    required this.hint,
    this.keyboardType,
    this.obscureText = false,
    this.autofocus   = false,
    this.maxLength,
    this.suffix,
    this.label,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller:   controller,
      keyboardType: keyboardType,
      obscureText:  obscureText,
      autofocus:    autofocus,
      maxLength:    maxLength,
      style: const TextStyle(color: C.t1, fontSize: 15),
      cursorColor:  C.accent,
      decoration: InputDecoration(
        hintText:    hint,
        labelText:   label,
        counterText: '',
        suffixIcon:  suffix,
      ),
    );
  }
}
