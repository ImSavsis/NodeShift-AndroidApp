#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────
# NodeShift VPN — quick build script
# Usage: ./scripts/build.sh [debug|release]
# ──────────────────────────────────────────────────────────
set -euo pipefail

MODE="${1:-debug}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

GREEN='\033[0;32m'; NC='\033[0m'
info() { echo -e "${GREEN}[BUILD]${NC} $*"; }

info "pub get..."
flutter pub get

if [[ "$MODE" == "release" ]]; then
    info "Сборка RELEASE APK..."
    flutter build apk --release --obfuscate --split-debug-info=debug-symbols/
    APK="build/app/outputs/flutter-apk/app-release.apk"
    OUT="NodeShift-release.apk"
else
    info "Сборка DEBUG APK..."
    flutter build apk --debug
    APK="build/app/outputs/flutter-apk/app-debug.apk"
    OUT="NodeShift-debug.apk"
fi

if [ -f "$APK" ]; then
    cp "$APK" "$OUT"
    SIZE=$(du -sh "$OUT" | cut -f1)
    info "✅ $OUT ($SIZE)"
    echo ""
    echo "  Установить: adb install $OUT"
    echo "  Установить на конкретный девайс: adb -s <device> install $OUT"
else
    echo "❌ Сборка не удалась"
    exit 1
fi
