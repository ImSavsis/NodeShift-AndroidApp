#!/usr/bin/env python3
"""
Creates a placeholder NodeShift icon (blue shield on dark background).
Run: python3 scripts/create_placeholder_icon.py
Output: assets/icon.png
"""
import sys, os
try:
    from PIL import Image, ImageDraw
except ImportError:
    print("pip install Pillow"); sys.exit(1)

SIZE = 1024
img  = Image.new("RGBA", (SIZE, SIZE), (10, 10, 10, 255))
draw = ImageDraw.Draw(img)

# Background circle
cx, cy, r = SIZE//2, SIZE//2, SIZE//2 - 40
draw.ellipse([cx-r, cy-r, cx+r, cy+r], fill=(59, 130, 246, 30))

# Shield
sw, sh = 340, 400
sx, sy = cx - sw//2, cy - sh//2 - 20
points = [
    (sx,         sy + sh*0.15),
    (sx + sw//2, sy),
    (sx + sw,    sy + sh*0.15),
    (sx + sw,    sy + sh*0.55),
    (sx + sw//2, sy + sh),
    (sx,         sy + sh*0.55),
]
draw.polygon(points, fill=(59, 130, 246, 255))
# Inner shield (lighter)
margin = 28
points2 = [
    (sx+margin,         sy + sh*0.15 + margin*0.7),
    (sx + sw//2,        sy + margin),
    (sx + sw - margin,  sy + sh*0.15 + margin*0.7),
    (sx + sw - margin,  sy + sh*0.55 - margin*0.3),
    (sx + sw//2,        sy + sh - margin),
    (sx + margin,       sy + sh*0.55 - margin*0.3),
]
draw.polygon(points2, fill=(96, 165, 250, 255))
# Checkmark
ck_x, ck_y = cx - 55, cy - 10
draw.line([ck_x, ck_y+40, ck_x+40, ck_y+80, ck_x+100, ck_y], fill=(255,255,255,255), width=22)

out = os.path.join(os.path.dirname(__file__), '..', 'assets', 'icon.png')
img.save(out, 'PNG')
print(f"✓ Created: {os.path.abspath(out)}")
