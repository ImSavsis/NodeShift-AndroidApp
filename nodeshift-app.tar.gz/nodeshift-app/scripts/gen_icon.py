#!/usr/bin/env python3
"""
Generate NodeShift VPN app icon for all Android densities.
Requires: pip install Pillow
Run: python3 scripts/gen_icon.py
Uses: assets/icon.png as source (1024x1024 recommended)
"""
import os
import sys
from pathlib import Path

try:
    from PIL import Image
except ImportError:
    print("Install Pillow: pip install Pillow")
    sys.exit(1)

ROOT   = Path(__file__).parent.parent
SRC    = ROOT / "assets" / "icon.png"
SIZES  = {
    "mipmap-mdpi":    48,
    "mipmap-hdpi":    72,
    "mipmap-xhdpi":   96,
    "mipmap-xxhdpi":  144,
    "mipmap-xxxhdpi": 192,
}
RES = ROOT / "android" / "app" / "src" / "main" / "res"

if not SRC.exists():
    print(f"Source icon not found: {SRC}")
    print("Place a 1024x1024 PNG at assets/icon.png")
    sys.exit(1)

img = Image.open(SRC).convert("RGBA")
for density, size in SIZES.items():
    outdir = RES / density
    outdir.mkdir(parents=True, exist_ok=True)
    out = outdir / "ic_launcher.png"
    resized = img.resize((size, size), Image.LANCZOS)
    resized.save(out, "PNG")
    print(f"  ✓ {density}/ic_launcher.png ({size}×{size})")

print(f"\nIcons generated in {RES}")
