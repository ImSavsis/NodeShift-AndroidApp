#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────
# NodeShift VPN — macOS / Linux setup script
# Installs Flutter SDK + Android SDK + builds debug APK
# ──────────────────────────────────────────────────────────
set -euo pipefail

FLUTTER_VERSION="3.22.2"
FLUTTER_DIR="$HOME/flutter"
ANDROID_HOME="$HOME/android-sdk"
ANDROID_BUILD_TOOLS="34.0.0"
ANDROID_PLATFORM="android-34"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info()  { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
error() { echo -e "${RED}[ERR]${NC} $*"; exit 1; }

# ── 1. Flutter ────────────────────────────────────────────
if [ -d "$FLUTTER_DIR" ]; then
  info "Flutter уже установлен в $FLUTTER_DIR"
else
  info "Скачиваем Flutter $FLUTTER_VERSION..."
  OS=$(uname -s | tr '[:upper:]' '[:lower:]')
  ARCH=$(uname -m)
  [[ "$ARCH" == "arm64" ]] && ARCH="arm64" || ARCH="x64"

  if [[ "$OS" == "darwin" ]]; then
    URL="https://storage.googleapis.com/flutter_infra_release/releases/stable/macos/flutter_macos_${ARCH}-${FLUTTER_VERSION}-stable.zip"
  else
    URL="https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_${FLUTTER_VERSION}-stable.tar.xz"
  fi

  cd "$HOME"
  if [[ "$OS" == "darwin" ]]; then
    curl -Lo flutter.zip "$URL" && unzip -q flutter.zip && rm flutter.zip
  else
    curl -Lo flutter.tar.xz "$URL" && tar xf flutter.tar.xz && rm flutter.tar.xz
  fi
  info "Flutter установлен"
fi

export PATH="$FLUTTER_DIR/bin:$PATH"

# ── 2. Android SDK (command-line tools) ───────────────────
if [ -d "$ANDROID_HOME" ]; then
  info "Android SDK уже есть в $ANDROID_HOME"
else
  info "Скачиваем Android SDK command-line tools..."
  mkdir -p "$ANDROID_HOME/cmdline-tools"
  cd /tmp
  curl -Lo cmdtools.zip "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
  unzip -q cmdtools.zip -d "$ANDROID_HOME/cmdline-tools"
  mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
  rm cmdtools.zip
fi

export ANDROID_HOME ANDROID_SDK_ROOT="$ANDROID_HOME"
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

# ── 3. SDK components ──────────────────────────────────────
info "Устанавливаем SDK компоненты..."
yes | sdkmanager --licenses > /dev/null 2>&1 || true
sdkmanager "platforms;$ANDROID_PLATFORM" "build-tools;$ANDROID_BUILD_TOOLS" "platform-tools" > /dev/null

# ── 4. Flutter config ──────────────────────────────────────
flutter config --android-sdk "$ANDROID_HOME" --no-analytics
flutter doctor --android-licenses < <(yes) 2>/dev/null || true
flutter doctor

# ── 5. Get packages ────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$SCRIPT_DIR"
info "Скачиваем pub packages..."
flutter pub get

# ── 6. Build APK ───────────────────────────────────────────
info "Сборка debug APK..."
flutter build apk --debug

APK="$SCRIPT_DIR/build/app/outputs/flutter-apk/app-debug.apk"
if [ -f "$APK" ]; then
  info "✅ APK готов: $APK"
  cp "$APK" "$SCRIPT_DIR/NodeShift-debug.apk"
  info "Скопирован как NodeShift-debug.apk"
else
  error "APK не найден после сборки"
fi

echo ""
echo "════════════════════════════════════════"
echo " Готово! Установите на телефон:"
echo " adb install NodeShift-debug.apk"
echo "════════════════════════════════════════"

# Append to shell profile
PROFILE="$HOME/.zshrc"
[[ -f "$HOME/.bashrc" ]] && PROFILE="$HOME/.bashrc"
grep -q "flutter/bin" "$PROFILE" 2>/dev/null || cat >> "$PROFILE" << EOF

# Flutter
export PATH="\$HOME/flutter/bin:\$PATH"
export ANDROID_HOME="\$HOME/android-sdk"
export ANDROID_SDK_ROOT="\$ANDROID_HOME"
export PATH="\$ANDROID_HOME/cmdline-tools/latest/bin:\$ANDROID_HOME/platform-tools:\$PATH"
EOF
info "PATH добавлен в $PROFILE. Перезапустите терминал или: source $PROFILE"
