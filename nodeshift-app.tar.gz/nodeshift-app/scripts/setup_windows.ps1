# ──────────────────────────────────────────────────────────
# NodeShift VPN — Windows setup script (PowerShell)
# Installs Flutter SDK + Android SDK + builds debug APK
# Run: Set-ExecutionPolicy -Scope Process Bypass; .\scripts\setup_windows.ps1
# ──────────────────────────────────────────────────────────
$ErrorActionPreference = "Stop"

$FLUTTER_VERSION  = "3.22.2"
$FLUTTER_DIR      = "$env:USERPROFILE\flutter"
$ANDROID_HOME     = "$env:USERPROFILE\android-sdk"

function Info  { param($msg) Write-Host "[INFO] $msg" -ForegroundColor Green }
function Warn  { param($msg) Write-Host "[WARN] $msg" -ForegroundColor Yellow }
function Err   { param($msg) Write-Host "[ERR]  $msg" -ForegroundColor Red; exit 1 }

# ── 1. Flutter ────────────────────────────────────────────
if (Test-Path $FLUTTER_DIR) {
    Info "Flutter уже установлен в $FLUTTER_DIR"
} else {
    Info "Скачиваем Flutter $FLUTTER_VERSION..."
    $url = "https://storage.googleapis.com/flutter_infra_release/releases/stable/windows/flutter_windows_${FLUTTER_VERSION}-stable.zip"
    $zip = "$env:TEMP\flutter.zip"
    Invoke-WebRequest $url -OutFile $zip
    Expand-Archive $zip -DestinationPath $env:USERPROFILE -Force
    Remove-Item $zip
    Info "Flutter установлен"
}

$env:PATH = "$FLUTTER_DIR\bin;$env:PATH"

# ── 2. Android SDK ────────────────────────────────────────
if (-not (Test-Path "$ANDROID_HOME\cmdline-tools")) {
    Info "Скачиваем Android SDK command-line tools..."
    New-Item -ItemType Directory -Force -Path "$ANDROID_HOME\cmdline-tools" | Out-Null
    $cmdUrl = "https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip"
    $cmdZip = "$env:TEMP\cmdtools.zip"
    Invoke-WebRequest $cmdUrl -OutFile $cmdZip
    Expand-Archive $cmdZip -DestinationPath "$ANDROID_HOME\cmdline-tools" -Force
    Rename-Item "$ANDROID_HOME\cmdline-tools\cmdline-tools" "latest"
    Remove-Item $cmdZip
}

$env:ANDROID_HOME       = $ANDROID_HOME
$env:ANDROID_SDK_ROOT   = $ANDROID_HOME
$env:PATH = "$ANDROID_HOME\cmdline-tools\latest\bin;$ANDROID_HOME\platform-tools;$env:PATH"

# ── 3. SDK components ──────────────────────────────────────
Info "Устанавливаем SDK компоненты..."
echo "y" | & sdkmanager --licenses 2>$null
& sdkmanager "platforms;android-34" "build-tools;34.0.0" "platform-tools"

# ── 4. Flutter config ──────────────────────────────────────
flutter config --android-sdk $ANDROID_HOME --no-analytics
flutter doctor

# ── 5. Get packages ────────────────────────────────────────
$SCRIPT_DIR = Split-Path -Parent $PSScriptRoot
Set-Location $SCRIPT_DIR
Info "Скачиваем pub packages..."
flutter pub get

# ── 6. Build APK ───────────────────────────────────────────
Info "Сборка debug APK..."
flutter build apk --debug

$APK = "$SCRIPT_DIR\build\app\outputs\flutter-apk\app-debug.apk"
if (Test-Path $APK) {
    Copy-Item $APK "$SCRIPT_DIR\NodeShift-debug.apk" -Force
    Info "✅ APK готов: $SCRIPT_DIR\NodeShift-debug.apk"
} else {
    Err "APK не найден"
}

Write-Host ""
Write-Host "════════════════════════════════════════" -ForegroundColor Cyan
Write-Host " Готово! Установите на телефон:"         -ForegroundColor Cyan
Write-Host " adb install NodeShift-debug.apk"        -ForegroundColor Cyan
Write-Host "════════════════════════════════════════" -ForegroundColor Cyan

# Persist env vars
[System.Environment]::SetEnvironmentVariable("FLUTTER_HOME", $FLUTTER_DIR, "User")
[System.Environment]::SetEnvironmentVariable("ANDROID_HOME", $ANDROID_HOME, "User")
